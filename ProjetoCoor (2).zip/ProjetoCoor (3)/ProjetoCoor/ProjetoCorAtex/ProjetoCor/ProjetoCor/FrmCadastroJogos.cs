﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmCadastroJogos : MetroFramework.Forms.MetroForm
    {
        public FrmCadastroJogos()
        {
            InitializeComponent();
        }

        private void btnCadastrarJogo_Click(object sender, EventArgs e)
        {
            FrmMenu fm = new FrmMenu();
            fm.ShowDialog();
        }
    }
}
