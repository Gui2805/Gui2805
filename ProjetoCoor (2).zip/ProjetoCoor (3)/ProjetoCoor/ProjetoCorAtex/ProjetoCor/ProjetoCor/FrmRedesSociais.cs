﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmRedesSociais : MetroFramework.Forms.MetroForm
    {
        public FrmRedesSociais()
        {
            InitializeComponent();
        }

        private void btnConsultarMaterial_Click_1(object sender, EventArgs e)
        {
            FrmLinkConfiguracao LC = new FrmLinkConfiguracao();
            LC.ShowDialog();
        }

        private void btnFinalizar_Click_1(object sender, EventArgs e)
        {
            FrmMenu MN = new FrmMenu();
            MN.ShowDialog();
        }

        private void btnNovaRede_Click_1(object sender, EventArgs e)
        {
            FrmCadastroRedesSociais CR = new FrmCadastroRedesSociais();
            CR.ShowDialog();
        }
    }
}
