﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmJogos : MetroFramework.Forms.MetroForm
    {
        public FrmJogos()
        {
            InitializeComponent();
        }
        private void btnRedesSociais_Click_1(object sender, EventArgs e)
        {
            FrmRedesSociais RS = new FrmRedesSociais();
            RS.ShowDialog();
        }

        private void btnNovoJogo_Click_1(object sender, EventArgs e)
        {
            FrmCadastroJogos CJ = new FrmCadastroJogos();
            CJ.ShowDialog();
        }
    }
}
