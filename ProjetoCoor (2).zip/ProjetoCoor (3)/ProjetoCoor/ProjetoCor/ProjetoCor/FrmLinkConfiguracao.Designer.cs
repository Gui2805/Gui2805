﻿namespace ProjetoCor
{
    partial class FrmLinkConfiguracao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFinalizar = new System.Windows.Forms.Button();
            this.btnOrientacoes = new System.Windows.Forms.Button();
            this.linkLabelRedesSociais = new System.Windows.Forms.LinkLabel();
            this.linkLabelJogos = new System.Windows.Forms.LinkLabel();
            this.linkLabelAparelho = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnFinalizar
            // 
            this.btnFinalizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(85)))), ((int)(((byte)(45)))));
            this.btnFinalizar.Location = new System.Drawing.Point(637, 361);
            this.btnFinalizar.Name = "btnFinalizar";
            this.btnFinalizar.Size = new System.Drawing.Size(112, 34);
            this.btnFinalizar.TabIndex = 11;
            this.btnFinalizar.Text = "Finalizar";
            this.btnFinalizar.UseVisualStyleBackColor = false;
            this.btnFinalizar.Click += new System.EventHandler(this.btnFinalizar_Click);
            // 
            // btnOrientacoes
            // 
            this.btnOrientacoes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnOrientacoes.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnOrientacoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrientacoes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(85)))), ((int)(((byte)(45)))));
            this.btnOrientacoes.Location = new System.Drawing.Point(479, 361);
            this.btnOrientacoes.Name = "btnOrientacoes";
            this.btnOrientacoes.Size = new System.Drawing.Size(123, 34);
            this.btnOrientacoes.TabIndex = 10;
            this.btnOrientacoes.Text = "Orientações";
            this.btnOrientacoes.UseVisualStyleBackColor = false;
            this.btnOrientacoes.Click += new System.EventHandler(this.btnOrientacoes_Click);
            // 
            // linkLabelRedesSociais
            // 
            this.linkLabelRedesSociais.AutoSize = true;
            this.linkLabelRedesSociais.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelRedesSociais.LinkColor = System.Drawing.Color.Black;
            this.linkLabelRedesSociais.Location = new System.Drawing.Point(54, 266);
            this.linkLabelRedesSociais.Name = "linkLabelRedesSociais";
            this.linkLabelRedesSociais.Size = new System.Drawing.Size(213, 17);
            this.linkLabelRedesSociais.TabIndex = 9;
            this.linkLabelRedesSociais.TabStop = true;
            this.linkLabelRedesSociais.Text = "Configuração das Redes Sociais";
            this.linkLabelRedesSociais.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelRedesSociais_LinkClicked);
            // 
            // linkLabelJogos
            // 
            this.linkLabelJogos.AutoSize = true;
            this.linkLabelJogos.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelJogos.LinkColor = System.Drawing.Color.Black;
            this.linkLabelJogos.Location = new System.Drawing.Point(54, 206);
            this.linkLabelJogos.Name = "linkLabelJogos";
            this.linkLabelJogos.Size = new System.Drawing.Size(161, 17);
            this.linkLabelJogos.TabIndex = 8;
            this.linkLabelJogos.TabStop = true;
            this.linkLabelJogos.Text = "Configuração dos Jogos";
            this.linkLabelJogos.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelJogos_LinkClicked);
            // 
            // linkLabelAparelho
            // 
            this.linkLabelAparelho.AutoSize = true;
            this.linkLabelAparelho.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelAparelho.LinkColor = System.Drawing.Color.Black;
            this.linkLabelAparelho.Location = new System.Drawing.Point(54, 149);
            this.linkLabelAparelho.Name = "linkLabelAparelho";
            this.linkLabelAparelho.Size = new System.Drawing.Size(164, 16);
            this.linkLabelAparelho.TabIndex = 7;
            this.linkLabelAparelho.TabStop = true;
            this.linkLabelAparelho.Text = "Configuração do Aparelho";
            this.linkLabelAparelho.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelAparelho_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(52, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 25);
            this.label1.TabIndex = 6;
            this.label1.Text = "Links para Configuração";
            // 
            // FrmLinkConfiguracao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnFinalizar);
            this.Controls.Add(this.btnOrientacoes);
            this.Controls.Add(this.linkLabelRedesSociais);
            this.Controls.Add(this.linkLabelJogos);
            this.Controls.Add(this.linkLabelAparelho);
            this.Controls.Add(this.label1);
            this.Name = "FrmLinkConfiguracao";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFinalizar;
        private System.Windows.Forms.Button btnOrientacoes;
        private System.Windows.Forms.LinkLabel linkLabelRedesSociais;
        private System.Windows.Forms.LinkLabel linkLabelJogos;
        private System.Windows.Forms.LinkLabel linkLabelAparelho;
        private System.Windows.Forms.Label label1;
    }
}