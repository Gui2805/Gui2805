﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmUsuario : MetroFramework.Forms.MetroForm
    {
        private Usuario usuarioBD;
        private int codigoUsuario;
        public FrmUsuario()
        {
            InitializeComponent();
            usuarioBD = new Usuario();
        }

        public int CodigoUsuario { get => codigoUsuario; set => codigoUsuario = value; }

        private void btnCadastrarUsuario_Click(object sender, EventArgs e)
        {
            //usuarioBD.IdUsuario = CodigoUsuario;
            usuarioBD.NomeUsuario = txtNome.Text;
            usuarioBD.DataNascimento = DateTime.Now;
            usuarioBD.Email = txtEmail.Text;
            usuarioBD.Telefone = txtCelular.Text;
            DateTime dataNascimento = dtNascimento.Value;
            string dataFormatada = dataNascimento.ToString("dd/MM/yyyy");
            usuarioBD.DataNascimento = DateTime.ParseExact(dataFormatada, "dd/MM/yyyy", null);

            if(rdEscolaPrivada.Checked)
            {
                usuarioBD.Escola = "Escola Privada";
            }else if(rdEscolaPublica.Checked)
            {
                usuarioBD.Escola = "Escola Pública";
            }

            usuarioBD.incluirUsuario();
            usuarioBD.pesquisaPorEmail();

            MessageBox.Show("Usuário cadastrado com sucesso");

            txtNome.Clear();
            txtEmail.Clear();
            txtCelular.Clear();
    

            FrmResposta frmResposta = new FrmResposta(usuarioBD.IdUsuario);
           // frmResposta.CodigoUsuario = usuarioBD.IdUsuario;
            frmResposta.ShowDialog();
        }
    }
}
