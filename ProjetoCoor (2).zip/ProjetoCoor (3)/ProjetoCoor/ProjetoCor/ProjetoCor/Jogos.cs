﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoCor
{
    internal class Jogos
    {
        private int idJogos;
        private string nomeJogos;
        private string urlJogos;
        private int idUsuario;

        private ConexaoBD Conect;

        public Jogos()
        {
            Conect = new ConexaoBD();
        }

        public string NomeJogos { get => nomeJogos; set => nomeJogos = value; }
        public string UrlJogos { get => urlJogos; set => urlJogos = value; }
        public int IdJogos { get => idJogos; set => idJogos = value; }
        public int IdUsuario { get => idUsuario; set => idUsuario = value; }

        public void incluirJogos()
        {
            string sql = $"INSERT INTO Jogos (nomeJogos, urlJogos) " +
                $"VALUES ('{NomeJogos}', '{urlJogos}')";
            Conect.executar(sql);
        }

        //public void pesquisarPorID()
        //{
        //    string sql = "SELECT * FROM Jogos WHERE idUsuarioJogos = " + idJogos.ToString();


        //    Conect.ConsultarPorID(sql);

        //    string[] vetorCampos = Conect.Campos.Split(';');
        //    nomeJogos = vetorCampos[2];
        //    urlJogos = vetorCampos[3];

        //}
    }
}
