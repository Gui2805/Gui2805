﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using System.Data.SqlClient;

namespace ProjetoCor
{
    internal class Usuario
    {
        private int idUsuario;
        private string nomeUsuario;
        private string email;
        private string telefone;
        private DateTime dataNascimento;
        private string escola;
        ConexaoBD Conect = null;

        public Usuario()
        {
            Conect = new ConexaoBD();
        }


        public string NomeUsuario { get => nomeUsuario; set => nomeUsuario = value; }
        public string Email { get => email; set => email = value; }
        public string Telefone { get => telefone; set => telefone = value; }
        public DateTime DataNascimento { get => dataNascimento; set => dataNascimento = value; }
        public int IdUsuario { get => idUsuario; set => idUsuario = value; }
        public string Escola { get => escola; set => escola = value; }



        public void incluirUsuario()
        {
            string sql = "";
            sql += $"INSERT INTO Usuario (nomeUsuario, dataNascimento, email, telefone, escola) " +
                $"VALUES ('{NomeUsuario}', '{DataNascimento.ToString("yyyy-MM-dd")}', '{Email}', '{Telefone}', '{Escola}')";
           Conect.executar(sql);
        }

        public void pesquisaPorEmail()
        {
            string sql = "";
            sql += $"SELECT idUsuario FROM Usuario WHERE email = '{Email}'" ;
            SqlConnection conexao = Conect.conexao();
            SqlCommand cmd = new SqlCommand();
            
            cmd.CommandText = sql;
            cmd.Connection = conexao;
            conexao.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            if(reader.Read())
            {
                idUsuario = int.Parse(reader["idUsuario"].ToString());
            }
            conexao.Close();
        }

        public void pesquisarPorID()
        {
            string sql = "SELECT * FROM Usuario WHERE idUsuario = " + idUsuario.ToString();
            Conect.ConsultarPorID(sql);

            string[] vetorCampos = Conect.Campos.Split(';');
            nomeUsuario = vetorCampos[2];
            if (DateTime.TryParse(vetorCampos[3], out DateTime dataNasc))
            {
                dataNascimento = dataNasc;
            }

            email = vetorCampos[4];
            telefone = vetorCampos[5];
            escola = vetorCampos[6];
        }

        public DataSet pesquisarDados()
        {
            string sql = "";
            sql = "SELECT * FROM Usuario";
            return Conect.listarDados(sql);
        }

        public void alterar()
        {
            string sql = $"UPDATE Usuario SET NomeUsuario = '{NomeUsuario}', DataNascimento = '{DataNascimento.ToString("yyyy-MM-dd")}', " +
                         $"Email = '{Email}', Telefone = '{Telefone}', Escola = '{Escola}' " +
                         $"WHERE idUsuario = {IdUsuario}";
            Conect.alterarDados(sql);
        }

        public void excluir()
        {
            Conect.excluir("DELETE FROM Usuario WHERE idUsuario =" + idUsuario);
        }
    }
}
