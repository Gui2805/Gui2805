﻿namespace ProjetoCor
{
    partial class FrmRedesSociais
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboYoutube = new System.Windows.Forms.CheckBox();
            this.cboInstagram = new System.Windows.Forms.CheckBox();
            this.cboFacebook = new System.Windows.Forms.CheckBox();
            this.cboTikTok = new System.Windows.Forms.CheckBox();
            this.btnNovaRede = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnFinalizar = new System.Windows.Forms.Button();
            this.btnConsultarMaterial = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cboYoutube
            // 
            this.cboYoutube.AutoSize = true;
            this.cboYoutube.Location = new System.Drawing.Point(104, 305);
            this.cboYoutube.Name = "cboYoutube";
            this.cboYoutube.Size = new System.Drawing.Size(85, 20);
            this.cboYoutube.TabIndex = 30;
            this.cboYoutube.Text = "YouTube";
            this.cboYoutube.UseVisualStyleBackColor = true;
            // 
            // cboInstagram
            // 
            this.cboInstagram.AutoSize = true;
            this.cboInstagram.Location = new System.Drawing.Point(398, 305);
            this.cboInstagram.Name = "cboInstagram";
            this.cboInstagram.Size = new System.Drawing.Size(88, 20);
            this.cboInstagram.TabIndex = 29;
            this.cboInstagram.Text = "Instagram";
            this.cboInstagram.UseVisualStyleBackColor = true;
            // 
            // cboFacebook
            // 
            this.cboFacebook.AutoSize = true;
            this.cboFacebook.Location = new System.Drawing.Point(398, 113);
            this.cboFacebook.Name = "cboFacebook";
            this.cboFacebook.Size = new System.Drawing.Size(91, 20);
            this.cboFacebook.TabIndex = 28;
            this.cboFacebook.Text = "Facebook";
            this.cboFacebook.UseVisualStyleBackColor = true;
            // 
            // cboTikTok
            // 
            this.cboTikTok.AutoSize = true;
            this.cboTikTok.Location = new System.Drawing.Point(104, 113);
            this.cboTikTok.Name = "cboTikTok";
            this.cboTikTok.Size = new System.Drawing.Size(75, 20);
            this.cboTikTok.TabIndex = 27;
            this.cboTikTok.Text = "Tik Tok";
            this.cboTikTok.UseVisualStyleBackColor = true;
            // 
            // btnNovaRede
            // 
            this.btnNovaRede.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(215)))), ((int)(((byte)(215)))));
            this.btnNovaRede.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnNovaRede.ForeColor = System.Drawing.Color.White;
            this.btnNovaRede.Location = new System.Drawing.Point(745, 331);
            this.btnNovaRede.Name = "btnNovaRede";
            this.btnNovaRede.Size = new System.Drawing.Size(154, 147);
            this.btnNovaRede.TabIndex = 26;
            this.btnNovaRede.Text = "\n+Novo Redes";
            this.btnNovaRede.UseVisualStyleBackColor = false;
            this.btnNovaRede.Click += new System.EventHandler(this.btnNovaRede_Click_1);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProjetoCor.Properties.Resources.image_4__1_;
            this.pictureBox4.Location = new System.Drawing.Point(84, 331);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(154, 147);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 25;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ProjetoCor.Properties.Resources.image_6;
            this.pictureBox5.Location = new System.Drawing.Point(371, 331);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(154, 147);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 24;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjetoCor.Properties.Resources.image_5__1_;
            this.pictureBox2.Location = new System.Drawing.Point(371, 139);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(154, 147);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjetoCor.Properties.Resources.image_1;
            this.pictureBox1.Location = new System.Drawing.Point(84, 139);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 147);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 22;
            this.pictureBox1.TabStop = false;
            // 
            // btnFinalizar
            // 
            this.btnFinalizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnFinalizar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(85)))), ((int)(((byte)(45)))));
            this.btnFinalizar.Location = new System.Drawing.Point(804, 27);
            this.btnFinalizar.Name = "btnFinalizar";
            this.btnFinalizar.Size = new System.Drawing.Size(112, 31);
            this.btnFinalizar.TabIndex = 21;
            this.btnFinalizar.Text = "Finalizar";
            this.btnFinalizar.UseVisualStyleBackColor = false;
            this.btnFinalizar.Click += new System.EventHandler(this.btnFinalizar_Click_1);
            // 
            // btnConsultarMaterial
            // 
            this.btnConsultarMaterial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnConsultarMaterial.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnConsultarMaterial.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(85)))), ((int)(((byte)(45)))));
            this.btnConsultarMaterial.Location = new System.Drawing.Point(605, 27);
            this.btnConsultarMaterial.Name = "btnConsultarMaterial";
            this.btnConsultarMaterial.Size = new System.Drawing.Size(184, 31);
            this.btnConsultarMaterial.TabIndex = 20;
            this.btnConsultarMaterial.Text = "Consultar material";
            this.btnConsultarMaterial.UseVisualStyleBackColor = false;
            this.btnConsultarMaterial.Click += new System.EventHandler(this.btnConsultarMaterial_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.8F);
            this.label1.Location = new System.Drawing.Point(10, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(471, 31);
            this.label1.TabIndex = 19;
            this.label1.Text = "Selecione as Redes Sociais utilizadas";
            // 
            // FrmRedesSociais
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 530);
            this.Controls.Add(this.cboYoutube);
            this.Controls.Add(this.cboInstagram);
            this.Controls.Add(this.cboFacebook);
            this.Controls.Add(this.cboTikTok);
            this.Controls.Add(this.btnNovaRede);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnFinalizar);
            this.Controls.Add(this.btnConsultarMaterial);
            this.Controls.Add(this.label1);
            this.Name = "FrmRedesSociais";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cboYoutube;
        private System.Windows.Forms.CheckBox cboInstagram;
        private System.Windows.Forms.CheckBox cboFacebook;
        private System.Windows.Forms.CheckBox cboTikTok;
        private System.Windows.Forms.Button btnNovaRede;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnFinalizar;
        private System.Windows.Forms.Button btnConsultarMaterial;
        private System.Windows.Forms.Label label1;
    }
}