﻿namespace ProjetoCor
{
    partial class FrmLinkInformativo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFinalizar = new System.Windows.Forms.Button();
            this.linkLabelReportagens = new System.Windows.Forms.LinkLabel();
            this.linkLabelPalestras = new System.Windows.Forms.LinkLabel();
            this.linkLabelLivros = new System.Windows.Forms.LinkLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnFinalizar
            // 
            this.btnFinalizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnFinalizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(85)))), ((int)(((byte)(45)))));
            this.btnFinalizar.Location = new System.Drawing.Point(607, 384);
            this.btnFinalizar.Margin = new System.Windows.Forms.Padding(4);
            this.btnFinalizar.Name = "btnFinalizar";
            this.btnFinalizar.Size = new System.Drawing.Size(127, 42);
            this.btnFinalizar.TabIndex = 11;
            this.btnFinalizar.Text = "Finalizar";
            this.btnFinalizar.UseVisualStyleBackColor = false;
            this.btnFinalizar.Click += new System.EventHandler(this.btnFinalizar_Click);
            // 
            // linkLabelReportagens
            // 
            this.linkLabelReportagens.AutoSize = true;
            this.linkLabelReportagens.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelReportagens.LinkColor = System.Drawing.Color.Black;
            this.linkLabelReportagens.Location = new System.Drawing.Point(45, 278);
            this.linkLabelReportagens.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelReportagens.Name = "linkLabelReportagens";
            this.linkLabelReportagens.Size = new System.Drawing.Size(90, 17);
            this.linkLabelReportagens.TabIndex = 10;
            this.linkLabelReportagens.TabStop = true;
            this.linkLabelReportagens.Text = "Reportagens";
            this.linkLabelReportagens.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelReportagens_LinkClicked);
            // 
            // linkLabelPalestras
            // 
            this.linkLabelPalestras.AutoSize = true;
            this.linkLabelPalestras.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelPalestras.LinkColor = System.Drawing.Color.Black;
            this.linkLabelPalestras.Location = new System.Drawing.Point(45, 206);
            this.linkLabelPalestras.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelPalestras.Name = "linkLabelPalestras";
            this.linkLabelPalestras.Size = new System.Drawing.Size(67, 17);
            this.linkLabelPalestras.TabIndex = 9;
            this.linkLabelPalestras.TabStop = true;
            this.linkLabelPalestras.Text = "Palestras";
            this.linkLabelPalestras.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelPalestras_LinkClicked);
            // 
            // linkLabelLivros
            // 
            this.linkLabelLivros.AutoSize = true;
            this.linkLabelLivros.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelLivros.LinkColor = System.Drawing.Color.Black;
            this.linkLabelLivros.Location = new System.Drawing.Point(45, 137);
            this.linkLabelLivros.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabelLivros.Name = "linkLabelLivros";
            this.linkLabelLivros.Size = new System.Drawing.Size(46, 17);
            this.linkLabelLivros.TabIndex = 8;
            this.linkLabelLivros.TabStop = true;
            this.linkLabelLivros.Text = "Livros";
            this.linkLabelLivros.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelLivros_LinkClicked);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 41);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "Links sobre orientações ";
            // 
            // FrmLinkInformativo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnFinalizar);
            this.Controls.Add(this.linkLabelReportagens);
            this.Controls.Add(this.linkLabelPalestras);
            this.Controls.Add(this.linkLabelLivros);
            this.Controls.Add(this.label1);
            this.Name = "FrmLinkInformativo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFinalizar;
        private System.Windows.Forms.LinkLabel linkLabelReportagens;
        private System.Windows.Forms.LinkLabel linkLabelPalestras;
        private System.Windows.Forms.LinkLabel linkLabelLivros;
        private System.Windows.Forms.Label label1;
    }
}