﻿namespace ProjetoCor
{
    partial class FrmResposta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label11 = new System.Windows.Forms.Label();
            this.btnResposta = new System.Windows.Forms.Button();
            this.rbWeb = new System.Windows.Forms.RadioButton();
            this.rbTablet = new System.Windows.Forms.RadioButton();
            this.rbCelular = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtQtdDias = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.rb6 = new System.Windows.Forms.RadioButton();
            this.rb5 = new System.Windows.Forms.RadioButton();
            this.rb4 = new System.Windows.Forms.RadioButton();
            this.rb3 = new System.Windows.Forms.RadioButton();
            this.rb2 = new System.Windows.Forms.RadioButton();
            this.rb1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.gbPergunta1 = new System.Windows.Forms.GroupBox();
            this.gbPergunta2 = new System.Windows.Forms.GroupBox();
            this.gbPergunta3 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtQtdHoras = new System.Windows.Forms.TextBox();
            this.txtPeriodo = new System.Windows.Forms.TextBox();
            this.gbPergunta1.SuspendLayout();
            this.gbPergunta2.SuspendLayout();
            this.gbPergunta3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(411, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(260, 17);
            this.label11.TabIndex = 47;
            this.label11.Text = "que seu filho(a) utiliza responda abaixo:";
            // 
            // btnResposta
            // 
            this.btnResposta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnResposta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(85)))), ((int)(((byte)(45)))));
            this.btnResposta.Location = new System.Drawing.Point(555, 410);
            this.btnResposta.Name = "btnResposta";
            this.btnResposta.Size = new System.Drawing.Size(75, 28);
            this.btnResposta.TabIndex = 46;
            this.btnResposta.Text = "Continuar";
            this.btnResposta.UseVisualStyleBackColor = false;
            this.btnResposta.Click += new System.EventHandler(this.btnResposta_Click);
            // 
            // rbWeb
            // 
            this.rbWeb.AutoSize = true;
            this.rbWeb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbWeb.Location = new System.Drawing.Point(160, 37);
            this.rbWeb.Name = "rbWeb";
            this.rbWeb.Size = new System.Drawing.Size(55, 21);
            this.rbWeb.TabIndex = 45;
            this.rbWeb.Text = "Web";
            this.rbWeb.UseVisualStyleBackColor = true;
            // 
            // rbTablet
            // 
            this.rbTablet.AutoSize = true;
            this.rbTablet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbTablet.Location = new System.Drawing.Point(82, 37);
            this.rbTablet.Name = "rbTablet";
            this.rbTablet.Size = new System.Drawing.Size(66, 21);
            this.rbTablet.TabIndex = 44;
            this.rbTablet.Text = "Tablet";
            this.rbTablet.UseVisualStyleBackColor = true;
            // 
            // rbCelular
            // 
            this.rbCelular.AutoSize = true;
            this.rbCelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCelular.Location = new System.Drawing.Point(5, 37);
            this.rbCelular.Name = "rbCelular";
            this.rbCelular.Size = new System.Drawing.Size(70, 21);
            this.rbCelular.TabIndex = 43;
            this.rbCelular.Text = "Celular";
            this.rbCelular.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(411, 257);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(192, 17);
            this.label9.TabIndex = 40;
            this.label9.Text = "Qual o horário mais utilizado:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(411, 184);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(271, 17);
            this.label8.TabIndex = 38;
            this.label8.Text = "Quantidades de dia utilizado por semana:";
            // 
            // txtQtdDias
            // 
            this.txtQtdDias.Location = new System.Drawing.Point(414, 149);
            this.txtQtdDias.Name = "txtQtdDias";
            this.txtQtdDias.Size = new System.Drawing.Size(228, 20);
            this.txtQtdDias.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(411, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(248, 17);
            this.label7.TabIndex = 36;
            this.label7.Text = "Tempo diário que utiliza a ferramenta:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(411, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(241, 17);
            this.label6.TabIndex = 35;
            this.label6.Text = "Sobre o tempo de uso da ferramenta";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(450, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(144, 25);
            this.label5.TabIndex = 34;
            this.label5.Text = "Tempo de uso:";
            // 
            // rb6
            // 
            this.rb6.AutoSize = true;
            this.rb6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6.Location = new System.Drawing.Point(98, 41);
            this.rb6.Name = "rb6";
            this.rb6.Size = new System.Drawing.Size(52, 21);
            this.rb6.TabIndex = 33;
            this.rb6.Text = "Não";
            this.rb6.UseVisualStyleBackColor = true;
            // 
            // rb5
            // 
            this.rb5.AutoSize = true;
            this.rb5.Checked = true;
            this.rb5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5.Location = new System.Drawing.Point(15, 41);
            this.rb5.Name = "rb5";
            this.rb5.Size = new System.Drawing.Size(49, 21);
            this.rb5.TabIndex = 32;
            this.rb5.TabStop = true;
            this.rb5.Text = "Sim";
            this.rb5.UseVisualStyleBackColor = true;
            // 
            // rb4
            // 
            this.rb4.AutoSize = true;
            this.rb4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb4.Location = new System.Drawing.Point(107, 38);
            this.rb4.Name = "rb4";
            this.rb4.Size = new System.Drawing.Size(52, 21);
            this.rb4.TabIndex = 30;
            this.rb4.Text = "Não";
            this.rb4.UseVisualStyleBackColor = true;
            // 
            // rb3
            // 
            this.rb3.AutoSize = true;
            this.rb3.Checked = true;
            this.rb3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3.Location = new System.Drawing.Point(11, 38);
            this.rb3.Name = "rb3";
            this.rb3.Size = new System.Drawing.Size(49, 21);
            this.rb3.TabIndex = 29;
            this.rb3.TabStop = true;
            this.rb3.Text = "Sim";
            this.rb3.UseVisualStyleBackColor = true;
            // 
            // rb2
            // 
            this.rb2.AutoSize = true;
            this.rb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2.Location = new System.Drawing.Point(109, 40);
            this.rb2.Name = "rb2";
            this.rb2.Size = new System.Drawing.Size(52, 21);
            this.rb2.TabIndex = 27;
            this.rb2.Text = "Não";
            this.rb2.UseVisualStyleBackColor = true;
            // 
            // rb1
            // 
            this.rb1.AutoSize = true;
            this.rb1.Checked = true;
            this.rb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb1.Location = new System.Drawing.Point(13, 40);
            this.rb1.Name = "rb1";
            this.rb1.Size = new System.Drawing.Size(49, 21);
            this.rb1.TabIndex = 26;
            this.rb1.TabStop = true;
            this.rb1.Text = "Sim";
            this.rb1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 25);
            this.label1.TabIndex = 24;
            this.label1.Text = "Questionário para os pais:";
            // 
            // gbPergunta1
            // 
            this.gbPergunta1.Controls.Add(this.rb2);
            this.gbPergunta1.Controls.Add(this.rb1);
            this.gbPergunta1.Location = new System.Drawing.Point(23, 93);
            this.gbPergunta1.Name = "gbPergunta1";
            this.gbPergunta1.Size = new System.Drawing.Size(235, 73);
            this.gbPergunta1.TabIndex = 48;
            this.gbPergunta1.TabStop = false;
            this.gbPergunta1.Text = "Possui acesso ao celular do seu filho(a):";
            // 
            // gbPergunta2
            // 
            this.gbPergunta2.Controls.Add(this.rb4);
            this.gbPergunta2.Controls.Add(this.rb3);
            this.gbPergunta2.Location = new System.Drawing.Point(23, 210);
            this.gbPergunta2.Name = "gbPergunta2";
            this.gbPergunta2.Size = new System.Drawing.Size(235, 68);
            this.gbPergunta2.TabIndex = 49;
            this.gbPergunta2.TabStop = false;
            this.gbPergunta2.Text = "Tem conhecimento sobre o que ele assiste:";
            // 
            // gbPergunta3
            // 
            this.gbPergunta3.Controls.Add(this.rb6);
            this.gbPergunta3.Controls.Add(this.rb5);
            this.gbPergunta3.Location = new System.Drawing.Point(22, 321);
            this.gbPergunta3.Name = "gbPergunta3";
            this.gbPergunta3.Size = new System.Drawing.Size(235, 74);
            this.gbPergunta3.TabIndex = 50;
            this.gbPergunta3.TabStop = false;
            this.gbPergunta3.Text = "Já pesquisou sobre o que o seu filho assiste ou joga:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbCelular);
            this.groupBox1.Controls.Add(this.rbTablet);
            this.groupBox1.Controls.Add(this.rbWeb);
            this.groupBox1.Location = new System.Drawing.Point(413, 327);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(222, 68);
            this.groupBox1.TabIndex = 51;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Aparelho mais utilizado:";
            // 
            // txtQtdHoras
            // 
            this.txtQtdHoras.Location = new System.Drawing.Point(410, 217);
            this.txtQtdHoras.Name = "txtQtdHoras";
            this.txtQtdHoras.Size = new System.Drawing.Size(227, 20);
            this.txtQtdHoras.TabIndex = 39;
            // 
            // txtPeriodo
            // 
            this.txtPeriodo.Location = new System.Drawing.Point(410, 289);
            this.txtPeriodo.Name = "txtPeriodo";
            this.txtPeriodo.Size = new System.Drawing.Size(227, 20);
            this.txtPeriodo.TabIndex = 52;
            // 
            // FrmResposta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(698, 461);
            this.Controls.Add(this.txtPeriodo);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbPergunta3);
            this.Controls.Add(this.gbPergunta2);
            this.Controls.Add(this.gbPergunta1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.btnResposta);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtQtdHoras);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtQtdDias);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FrmResposta";
            this.Padding = new System.Windows.Forms.Padding(15, 60, 15, 16);
            this.gbPergunta1.ResumeLayout(false);
            this.gbPergunta1.PerformLayout();
            this.gbPergunta2.ResumeLayout(false);
            this.gbPergunta2.PerformLayout();
            this.gbPergunta3.ResumeLayout(false);
            this.gbPergunta3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnResposta;
        private System.Windows.Forms.RadioButton rbWeb;
        private System.Windows.Forms.RadioButton rbTablet;
        private System.Windows.Forms.RadioButton rbCelular;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtQtdDias;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rb6;
        private System.Windows.Forms.RadioButton rb5;
        private System.Windows.Forms.RadioButton rb4;
        private System.Windows.Forms.RadioButton rb3;
        private System.Windows.Forms.RadioButton rb2;
        private System.Windows.Forms.RadioButton rb1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbPergunta1;
        private System.Windows.Forms.GroupBox gbPergunta2;
        private System.Windows.Forms.GroupBox gbPergunta3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtQtdHoras;
        private System.Windows.Forms.TextBox txtPeriodo;
    }
}