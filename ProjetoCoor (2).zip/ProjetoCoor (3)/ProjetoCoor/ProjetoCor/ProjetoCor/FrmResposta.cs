﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmResposta : MetroFramework.Forms.MetroForm
    {
        private Usuario usuarioBD;
        private Resposta respostaBD;
        private QuestionarioPais questionarioBD;
        private UsuarioQuestionarioPais usuarioQuestionarioPaisBD;
        private int codigoUsuario;
        private int codigoQuestionario;
        private int codigoRespostaUsuario;

        public FrmResposta(int id)
        {
            InitializeComponent();
            respostaBD = new Resposta();
            questionarioBD = new QuestionarioPais();
            usuarioBD = new Usuario();
            usuarioQuestionarioPaisBD = new UsuarioQuestionarioPais();
            CodigoUsuario = id;
        }

        public int CodigoUsuario { get => codigoUsuario; set => codigoUsuario = value; }
        public int CodigoRespostaUsuario { get => codigoRespostaUsuario; set => codigoRespostaUsuario = value; }
        public int CodigoQuestionario { get => codigoQuestionario; set => codigoQuestionario = value; }

        private void btnResposta_Click(object sender, EventArgs e)
        {
            //Resposta
            usuarioBD.IdUsuario = codigoUsuario;
            respostaBD.QtdDias = txtQtdDias.Text;
            respostaBD.QtdHoras = txtQtdHoras.Text;
            respostaBD.Periodo = txtQtdHoras.Text;

            if (rbCelular.Checked )
            {
                respostaBD.Aparelho = "Celular";
            }else if(rbTablet.Checked ) 
            {
                respostaBD.Aparelho = "Tablet";
            }else if(rbWeb.Checked )
            {
                respostaBD.Aparelho = "Computador";
            }

            respostaBD.IdUsuario = codigoUsuario;
            respostaBD.incluirResposta();


            //Questionario Pais

   
            if (rb1.Checked || rb2.Checked)
            {
                questionarioBD.Pergunta = "Possui acesso ao celular do seu filho?";
                questionarioBD.incluirQuestionarioPais("Pergunta1");

                if (rb1.Checked)
                    usuarioQuestionarioPaisBD.Resposta = "Sim";
                else if (rb2.Checked)
                    usuarioQuestionarioPaisBD.Resposta = "Não";

                usuarioBD.IdUsuario = codigoUsuario;
                questionarioBD.IdQuestionarioPais = codigoQuestionario;

                usuarioQuestionarioPaisBD.IdQuestionarioPais =  questionarioBD.pesquisaIDUP();

                usuarioQuestionarioPaisBD.IdUsuario = codigoUsuario;
                //usuarioQuestionarioPaisBD.IdQuestionarioPais = codigoQuestionario;

               
                usuarioQuestionarioPaisBD.incluirUsuarioQuestionario();
            }

            if (rb3.Checked || rb4.Checked)
            {
                questionarioBD.Pergunta1 = "Tem conhecimento sobre o que ele assiste?";
                questionarioBD.incluirQuestionarioPais("Pergunta2");
                if (rb3.Checked)
                    usuarioQuestionarioPaisBD.Resposta = "Sim";
                else if (rb4.Checked)
                    usuarioQuestionarioPaisBD.Resposta = "Não";
            }
            
            if (rb5.Checked || rb6.Checked)
            {
                questionarioBD.Pergunta2 = "Já pesquisou sobre o que seu filho assiste ou joga?";
                questionarioBD.incluirQuestionarioPais("Pergunta3");
                if (rb5.Checked)
                    usuarioQuestionarioPaisBD.Resposta = "Sim";
                else if (rb5.Checked)
                    usuarioQuestionarioPaisBD.Resposta = "Não";
            }



            MessageBox.Show("Respostas salvas com sucesso!");

            FrmJogos Fj = new FrmJogos(usuarioBD.IdUsuario);
            Fj.ShowDialog();
        }
    }
}
