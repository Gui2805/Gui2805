﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ProjetoCor
{
    internal class Resposta
    {
        private int idResposta;
        private string qtdDias;
        private string qtdHoras;
        private string periodo;
        private string aparelho;
        private int idUsuario;

        ConexaoBD Conect = new ConexaoBD();

        public string QtdDias { get => qtdDias; set => qtdDias = value; }
        public string QtdHoras { get => qtdHoras; set => qtdHoras = value; }
        public string Periodo { get => periodo; set => periodo = value; }
        public int IdResposta { get => idResposta; set => idResposta = value; }
        public string Aparelho { get => aparelho; set => aparelho = value; }
        public int IdUsuario { get => idUsuario; set => idUsuario = value; }

        public void incluirResposta()
        {
            string sql = "";
            sql += $"INSERT INTO Resposta (qtdDias, qtdHoras, periodo, aparelho, idUsuario) " +
                $"VALUES ('{QtdDias}', '{qtdHoras}', '{Periodo}', '{Aparelho}', '{IdUsuario}')";
            Conect.executar(sql);
        }

        public void pesquisarPorID()
        {
            string sql = "SELECT * FROM Resposta WHERE idResposta = " + idResposta.ToString();
            Conect.ConsultarPorID(sql);

            string[] vetorCampos = Conect.Campos.Split(';');

            qtdDias = vetorCampos[2];
            qtdHoras = vetorCampos[3];
            periodo = vetorCampos[4];
            aparelho = vetorCampos[5];
            if (int.TryParse(vetorCampos[6], out int id))
            {
                idUsuario = id;
            }
        }

        public DataSet pesquisarDados()
        {
            string sql = "";
            sql = "SELECT * FROM Resposta";
            return Conect.listarDados(sql);
        }

        public void ConsultarDados()
        {
            string sql = "";
            sql += "SELECT ProjetoCoorFinal FROM Resposta WHERE idResposta = " + idResposta.ToString();
            Conect.ConsultarPorID(sql);
        }

        public void ExcluirDados()
        {
            string sql = "DELETE FROM Resposta WHERE idResposta = " + IdResposta.ToString();
            Conect.excluir(sql);
        }


    }
}
