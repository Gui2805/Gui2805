﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoCor
{
    class ConexaoBD
    {
        private string campos;
        private SqlConnection Conect = null;
        private SqlCommand Comando = new SqlCommand();

        public string Campos { get => campos; set => campos = value; }

        public ConexaoBD() 
        { 
            Conect = new SqlConnection();
            Conect.ConnectionString = "Server =.\\SQLEXPRESS; Database = ProjetoCoorFinal; UID = sa; PWD = 2810";
        }

        public void conectar()
        {
            string sql = "";
            sql = "Server =.\\SQLEXPRESS; Database = ProjetoCoorFinal; UID = sa; PWD = 2810";
            Conect.ConnectionString = sql;
            Conect.Open();
        }

        public void desconectar()
        {
            Conect.Close();
        }

        public void executar(string sql)
        {
            conectar();
            Comando.Connection = Conect;
            Comando.CommandText = sql;
            Comando.ExecuteNonQuery();
            desconectar();
        }

        public SqlCommand Comand(string sql)
        {
            Comando.Connection = Conect;
            Comando.CommandText = sql;
            return Comando;
        }

        public SqlConnection conexao()
        {
            return Conect;
        }



        public DataSet listarDados(string sql)
        {
            conectar();
            SqlDataAdapter da = new SqlDataAdapter(sql, Conect);

            DataSet ds = new DataSet();
            da.Fill(ds);
            desconectar();
            return ds;
        }

        public void alterarDados (string sql)
        {
            conectar();
            Comando.Connection= Conect;
            Comando.CommandText= sql;
            Comando.ExecuteNonQuery();
            Conect.Close();
        }

        public void excluir(string sql)
        {
            conectar();
            Comando.Connection = Conect;
            Comando.CommandText = sql;
            Comando.ExecuteNonQuery();
            Conect.Close();
        }

        public void ConsultarPorID(string sql)
        {
            conectar();
            Comando.Connection = Conect;
            Comando.CommandText = sql;

            SqlDataReader dr = Comando.ExecuteReader();
            Campos = "";

            if (dr.Read())
            {
                Campos = dr[0].ToString();
            }
            desconectar();
        }
    }
}
