﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmLinkInformativo : MetroFramework.Forms.MetroForm
    {
        public FrmLinkInformativo()
        {
            InitializeComponent();
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            FrmMenu fm = new FrmMenu();
            fm.ShowDialog();
        }

        private void linkLabelLivros_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabelLivros.LinkVisited = true;
            System.Diagnostics.Process.Start("https://drive.google.com/drive/folders/1tbFauuXZWID3rsAuAsyY82WsxVWuGwp6");
        }

        private void linkLabelPalestras_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabelPalestras.LinkVisited = true;
            System.Diagnostics.Process.Start("https://drive.google.com/drive/folders/1ilbRatw62ucy9jMm4uoZWb399cPpiq-H");
        }

        private void linkLabelReportagens_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabelReportagens.LinkVisited = true;
            System.Diagnostics.Process.Start("https://drive.google.com/drive/folders/1udIm9t0AwSR8tSEUCKPouQ4HfFY5k8fi");
        }
    }
}
