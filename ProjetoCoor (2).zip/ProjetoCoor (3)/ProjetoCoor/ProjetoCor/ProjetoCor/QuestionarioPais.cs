﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoCor
{
    internal class QuestionarioPais
    {
        private int idQuestionarioPais;
        private string pergunta;
        private string pergunta1;
        private string pergunta2;
        private string sim;
        private string nao;
        private int idUsuario;

        private ConexaoBD Conect;

        public QuestionarioPais()
        {
            Conect = new ConexaoBD();
        }

        public string Pergunta { get => pergunta; set => pergunta = value; }
        public int IdQuestionarioPais { get => idQuestionarioPais; set => idQuestionarioPais = value; }
        public string Sim { get => sim; set => sim = value; }
        public string Nao { get => nao; set => nao = value; }
        public int IdUsuario { get => idUsuario; set => idUsuario = value; }
        public string Pergunta1 { get => pergunta1; set => pergunta1 = value; }
        public string Pergunta2 { get => pergunta2; set => pergunta2 = value; }

        public void incluirQuestionarioPais(string pergunta)
        {
            string sql = $"INSERT INTO QuestionarioPais (pergunta) " +
                $"VALUES ('{Pergunta}')";
            Conect.executar(sql);
        }

        public int pesquisaIDUP()
        {
            string sql = "";
            sql += $"SELECT idQuestionarioPais FROM QuestionarioPais WHERE idQuestionarioPais = '{idQuestionarioPais}'";
            SqlConnection conexao = Conect.conexao();
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = sql;
            cmd.Connection = conexao;
            conexao.Open();

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                idQuestionarioPais = Convert.ToInt32(reader["idQuestionarioPais"]);
            }
            conexao.Close();

            return idQuestionarioPais;
        }
    }
}
