﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ProjetoCor
{
    internal class UsuarioJogos
    {
        private int idUsuario;
        private int idJogo;
        private int idUsuarioJogos;
        private ConexaoBD Conect;

        public UsuarioJogos()
        {
            Conect = new ConexaoBD();
        }

        public int IdUsuarioJogos { get => idUsuarioJogos; set => idUsuarioJogos = value; }
        public int IdJogo { get => idJogo; set => idJogo = value; }
        public int IdUsuario { get => idUsuario; set => idUsuario = value; }

        public void incluirUsuarioJogos()
        {
            string sql = $"INSERT INTO UsuarioJogos (idUsuario, idJogos) " +
                $"VALUES ('{IdUsuario}', '{IdJogo}')";
            Conect.executar(sql);
        }

        //public void pesquisarPorID()
        //{
        //    string sql = "SELECT * FROM UsuarioJogos WHERE idUsuarioJogos = " + idUsuarioJogos.ToString();


        //    Conect.ConsultarPorID(sql);

        //    string[] vetorCampos = Conect.Campos.Split(';');
        //    idUsuario = int.Parse(vetorCampos[2]);
        //    idJogo = int.Parse(vetorCampos[3]);

        //}
    }
}
