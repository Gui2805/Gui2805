﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmJogos : MetroFramework.Forms.MetroForm
    {
        private Jogos jogosBD;
        private Usuario usuarioBD;
        private UsuarioJogos usuarioJogosBD;
        private int codigo;
        

        public int Codigo { get => codigo; set => codigo = value; }

        public FrmJogos(int id)
        {
            InitializeComponent();
            jogosBD = new Jogos();
            usuarioBD = new Usuario();
            usuarioJogosBD = new UsuarioJogos();
            Codigo = id;
        }
        private void btnRedesSociais_Click_1(object sender, EventArgs e)
        {
            jogosBD.IdJogos = usuarioBD.IdUsuario;

            if (cboMinecraft.Checked)
            {
                jogosBD.NomeJogos = "Minecraft";
                jogosBD.UrlJogos = "https://drive.google.com/drive/folders/13Os7S0GqJnBMV3HPmh0UpYTsUTCSUwag?usp=drive_link";

            }
            else if (cboFreeFire.Checked)
            {
                jogosBD.NomeJogos = "FreeFire";
                jogosBD.UrlJogos = "https://drive.google.com/drive/folders/13Os7S0GqJnBMV3HPmh0UpYTsUTCSUwag?usp=drive_link";
            }
            else if (cboSubwaySurf.Checked)
            {
                jogosBD.NomeJogos = "Subway Surf";
                jogosBD.UrlJogos = "https://drive.google.com/drive/folders/13Os7S0GqJnBMV3HPmh0UpYTsUTCSUwag?usp=drive_link";
            }
            else if (cboStumbleGuys.Checked)
            {
                jogosBD.NomeJogos = "Stumble Guys";
                jogosBD.UrlJogos = "https://drive.google.com/drive/folders/13Os7S0GqJnBMV3HPmh0UpYTsUTCSUwag?usp=drive_link";
            }
            else if (cboRoblox.Checked)
            {
                jogosBD.NomeJogos = "Roblox";
                jogosBD.UrlJogos = "https://drive.google.com/drive/folders/13Os7S0GqJnBMV3HPmh0UpYTsUTCSUwag?usp=drive_link";
            }

            jogosBD.incluirJogos();

            usuarioJogosBD.IdJogo = usuarioBD.IdUsuario;
            usuarioJogosBD.IdUsuario = jogosBD.IdJogos;

            usuarioJogosBD.incluirUsuarioJogos();
            FrmRedesSociais RS = new FrmRedesSociais();
            RS.ShowDialog();
        }

        private void btnNovoJogo_Click_1(object sender, EventArgs e)
        {
            FrmCadastroJogos CJ = new FrmCadastroJogos();
            CJ.ShowDialog();
        }
    }
}
