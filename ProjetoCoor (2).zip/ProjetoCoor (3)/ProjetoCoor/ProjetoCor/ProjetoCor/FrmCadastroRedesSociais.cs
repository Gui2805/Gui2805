﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmCadastroRedesSociais : MetroFramework.Forms.MetroForm
    {
        private RedesSociais redesSociaisBD;
        public FrmCadastroRedesSociais()
        {
            InitializeComponent();
            redesSociaisBD = new RedesSociais();
        }

        private void btnCadastroRedeSocial_Click(object sender, EventArgs e)
        {
            redesSociaisBD.NomeRedeSocial = txtRedeSocial.Text;
            redesSociaisBD.incluirRedes();
            FrmMenu f1 = new FrmMenu();
            f1.ShowDialog();
        }
    }
}
