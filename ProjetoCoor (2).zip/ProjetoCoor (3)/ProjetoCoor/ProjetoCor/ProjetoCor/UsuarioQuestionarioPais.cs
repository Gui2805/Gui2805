﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ProjetoCor
{
    internal class UsuarioQuestionarioPais
    {
        private int idUsuario;
        private int idQuestionarioPais;
        private int idUsuarioQuestionario;
        private string resposta;

        private ConexaoBD Conect;

       

        public UsuarioQuestionarioPais()
        {
            Conect = new ConexaoBD();
        }

        public int IdUsuario { get => idUsuario; set => idUsuario = value; }
        public int IdQuestionarioPais { get => idQuestionarioPais; set => idQuestionarioPais = value; }
        public string Resposta { get => resposta; set => resposta = value; }
        public int IdUsuarioQuestionario { get => idUsuarioQuestionario; set => idUsuarioQuestionario = value; }

        public void incluirUsuarioQuestionario()
        {
            string sql = $"INSERT INTO UsuarioQuestionarioPais (idUsuario, idQuestionarioPais, resposta) " +
                $"VALUES ('{IdUsuario}', '{IdQuestionarioPais}', '{Resposta}')";
            Conect.executar(sql);
        }
    }
}
