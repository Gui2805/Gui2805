﻿namespace ProjetoCor
{
    partial class FrmJogos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboRoblox = new System.Windows.Forms.CheckBox();
            this.cboStumbleGuys = new System.Windows.Forms.CheckBox();
            this.cboSubwaySurf = new System.Windows.Forms.CheckBox();
            this.cboFreeFire = new System.Windows.Forms.CheckBox();
            this.cboMinecraft = new System.Windows.Forms.CheckBox();
            this.btnNovoJogo = new System.Windows.Forms.Button();
            this.btnRedesSociais = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cboRoblox
            // 
            this.cboRoblox.AutoSize = true;
            this.cboRoblox.Location = new System.Drawing.Point(408, 323);
            this.cboRoblox.Name = "cboRoblox";
            this.cboRoblox.Size = new System.Drawing.Size(72, 20);
            this.cboRoblox.TabIndex = 27;
            this.cboRoblox.Text = "Roblox";
            this.cboRoblox.UseVisualStyleBackColor = true;
            // 
            // cboStumbleGuys
            // 
            this.cboStumbleGuys.AutoSize = true;
            this.cboStumbleGuys.Location = new System.Drawing.Point(121, 323);
            this.cboStumbleGuys.Name = "cboStumbleGuys";
            this.cboStumbleGuys.Size = new System.Drawing.Size(112, 20);
            this.cboStumbleGuys.TabIndex = 26;
            this.cboStumbleGuys.Text = "Stumble Guys";
            this.cboStumbleGuys.UseVisualStyleBackColor = true;
            // 
            // cboSubwaySurf
            // 
            this.cboSubwaySurf.AutoSize = true;
            this.cboSubwaySurf.Location = new System.Drawing.Point(694, 113);
            this.cboSubwaySurf.Name = "cboSubwaySurf";
            this.cboSubwaySurf.Size = new System.Drawing.Size(103, 20);
            this.cboSubwaySurf.TabIndex = 25;
            this.cboSubwaySurf.Text = "Subway Surf";
            this.cboSubwaySurf.UseVisualStyleBackColor = true;
            // 
            // cboFreeFire
            // 
            this.cboFreeFire.AutoSize = true;
            this.cboFreeFire.Location = new System.Drawing.Point(408, 113);
            this.cboFreeFire.Name = "cboFreeFire";
            this.cboFreeFire.Size = new System.Drawing.Size(80, 20);
            this.cboFreeFire.TabIndex = 24;
            this.cboFreeFire.Text = "FreeFire";
            this.cboFreeFire.UseVisualStyleBackColor = true;
            // 
            // cboMinecraft
            // 
            this.cboMinecraft.AutoSize = true;
            this.cboMinecraft.Location = new System.Drawing.Point(121, 113);
            this.cboMinecraft.Name = "cboMinecraft";
            this.cboMinecraft.Size = new System.Drawing.Size(83, 20);
            this.cboMinecraft.TabIndex = 23;
            this.cboMinecraft.Text = "Minecraft";
            this.cboMinecraft.UseVisualStyleBackColor = true;
            // 
            // btnNovoJogo
            // 
            this.btnNovoJogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(215)))), ((int)(((byte)(215)))));
            this.btnNovoJogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnNovoJogo.ForeColor = System.Drawing.Color.White;
            this.btnNovoJogo.Location = new System.Drawing.Point(668, 359);
            this.btnNovoJogo.Name = "btnNovoJogo";
            this.btnNovoJogo.Size = new System.Drawing.Size(154, 147);
            this.btnNovoJogo.TabIndex = 22;
            this.btnNovoJogo.Text = "\n+Novo Jogo";
            this.btnNovoJogo.UseVisualStyleBackColor = false;
            this.btnNovoJogo.Click += new System.EventHandler(this.btnNovoJogo_Click_1);
            // 
            // btnRedesSociais
            // 
            this.btnRedesSociais.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(200)))), ((int)(((byte)(0)))));
            this.btnRedesSociais.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnRedesSociais.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(85)))), ((int)(((byte)(45)))));
            this.btnRedesSociais.Location = new System.Drawing.Point(586, 49);
            this.btnRedesSociais.Name = "btnRedesSociais";
            this.btnRedesSociais.Size = new System.Drawing.Size(236, 31);
            this.btnRedesSociais.TabIndex = 21;
            this.btnRedesSociais.Text = "Ir para as redes sociais";
            this.btnRedesSociais.UseVisualStyleBackColor = false;
            this.btnRedesSociais.Click += new System.EventHandler(this.btnRedesSociais_Click_1);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ProjetoCor.Properties.Resources.image_4;
            this.pictureBox4.Location = new System.Drawing.Point(92, 359);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(154, 147);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 20;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ProjetoCor.Properties.Resources.image_5;
            this.pictureBox5.Location = new System.Drawing.Point(381, 359);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(154, 147);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 19;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProjetoCor.Properties.Resources._643x0w;
            this.pictureBox3.Location = new System.Drawing.Point(668, 148);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(154, 147);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjetoCor.Properties.Resources.Free_fire_battlegrounds;
            this.pictureBox2.Location = new System.Drawing.Point(381, 148);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(154, 147);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjetoCor.Properties.Resources.Minecraft_capa;
            this.pictureBox1.Location = new System.Drawing.Point(92, 148);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 147);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.8F);
            this.label1.Location = new System.Drawing.Point(86, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(434, 31);
            this.label1.TabIndex = 15;
            this.label1.Text = "Selecione os Jogos mais utilizados";
            // 
            // FrmJogos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 554);
            this.Controls.Add(this.cboRoblox);
            this.Controls.Add(this.cboStumbleGuys);
            this.Controls.Add(this.cboSubwaySurf);
            this.Controls.Add(this.cboFreeFire);
            this.Controls.Add(this.cboMinecraft);
            this.Controls.Add(this.btnNovoJogo);
            this.Controls.Add(this.btnRedesSociais);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "FrmJogos";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox cboRoblox;
        private System.Windows.Forms.CheckBox cboStumbleGuys;
        private System.Windows.Forms.CheckBox cboSubwaySurf;
        private System.Windows.Forms.CheckBox cboFreeFire;
        private System.Windows.Forms.CheckBox cboMinecraft;
        private System.Windows.Forms.Button btnNovoJogo;
        private System.Windows.Forms.Button btnRedesSociais;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}