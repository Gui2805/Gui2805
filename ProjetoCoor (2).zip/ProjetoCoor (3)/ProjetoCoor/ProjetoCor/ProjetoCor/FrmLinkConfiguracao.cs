﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmLinkConfiguracao : MetroFramework.Forms.MetroForm
    {
        public FrmLinkConfiguracao()
        {
            InitializeComponent();
        }

        private void linkLabelAparelho_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabelAparelho.LinkVisited = true;
            System.Diagnostics.Process.Start("https://drive.google.com/drive/folders/1JmCYegoSocMScsEhP0gJdXxBi-NU5H3w");
        }

        private void linkLabelJogos_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabelJogos.LinkVisited = true;
            System.Diagnostics.Process.Start("https://drive.google.com/drive/folders/13Os7S0GqJnBMV3HPmh0UpYTsUTCSUwag");
        }

        private void linkLabelRedesSociais_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabelRedesSociais.LinkVisited = true;
            System.Diagnostics.Process.Start("https://drive.google.com/drive/folders/1Nncv5UaI1m0fqdP5k3aSr9imd-SvnuKs");
        }

        private void btnOrientacoes_Click(object sender, EventArgs e)
        {
            FrmLinkInformativo fli = new FrmLinkInformativo();
            fli.ShowDialog();
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            FrmMenu fm = new FrmMenu();
            fm.ShowDialog();
        }
    }
}
