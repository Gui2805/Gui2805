﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoCor
{
    public partial class FrmRedesSociais : MetroFramework.Forms.MetroForm
    {
        private RedesSociais redesBD;
        public FrmRedesSociais()
        {
            InitializeComponent();
            redesBD = new RedesSociais();
        }

        private void btnConsultarMaterial_Click_1(object sender, EventArgs e)
        {
           
            FrmLinkConfiguracao LC = new FrmLinkConfiguracao();
            LC.ShowDialog();
        }

        private void btnFinalizar_Click_1(object sender, EventArgs e)
        {
            if (cboTikTok.Checked)
            {
                redesBD.NomeRedeSocial = "Tik Tok";
                redesBD.UrlRedesSociais = "https://drive.google.com/drive/folders/1Nncv5UaI1m0fqdP5k3aSr9imd-SvnuKs?usp=drive_link";

            }
            else if (cboFacebook.Checked)
            {
                redesBD.NomeRedeSocial = "Facebook";
                redesBD.UrlRedesSociais = "https://drive.google.com/drive/folders/1Nncv5UaI1m0fqdP5k3aSr9imd-SvnuKs?usp=drive_link";
            }
            else if (cboInstagram.Checked)
            {
                redesBD.NomeRedeSocial = "Instagram";
                redesBD.UrlRedesSociais = "https://drive.google.com/drive/folders/1Nncv5UaI1m0fqdP5k3aSr9imd-SvnuKs?usp=drive_link";
            }
            else if (cboYoutube.Checked)
            {
                redesBD.NomeRedeSocial = "Youtube";
                redesBD.UrlRedesSociais = "https://drive.google.com/drive/folders/1Nncv5UaI1m0fqdP5k3aSr9imd-SvnuKs?usp=drive_link";
            }

            redesBD.incluirRedes();

            FrmMenu MN = new FrmMenu();
            MN.ShowDialog();
        }

        private void btnNovaRede_Click_1(object sender, EventArgs e)
        {
            FrmCadastroRedesSociais CR = new FrmCadastroRedesSociais();
            CR.ShowDialog();
        }
    }
}
