﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoCor
{
    internal class UsuarioRedesSociais
    {
        private int idUsuario;
        private int idRedesSociais;
        private int idUsuarioRedesSociais;
        private string canal;
        private ConexaoBD Conect;

        public UsuarioRedesSociais()
        {
            Conect = new ConexaoBD();
        }
        public int IdRedesSociais { get => idRedesSociais; set => idRedesSociais = value; }
        public int IdUsuario { get => idUsuario; set => idUsuario = value; }
        public int IdUsuarioRedesSociais { get => idUsuarioRedesSociais; set => idUsuarioRedesSociais = value; }
        public string Canal { get => canal; set => canal = value; }

        public void incluirUsuarioJogos()
        {
            string sql = $"INSERT INTO UsuarioRedesSociais (idUsuario, idRedesSociais, canal) " +
                $"VALUES ('{IdUsuario}', '{IdRedesSociais}', '{Canal}')";
            Conect.executar(sql);
        }

        public void pesquisarPorID()
        {
            string sql = "SELECT * FROM UsuarioRedesSociais WHERE idUsuarioRedesSociais = " + idUsuarioRedesSociais.ToString();


            Conect.ConsultarPorID(sql);

            string[] vetorCampos = Conect.Campos.Split(';');
            idUsuario = int.Parse(vetorCampos[2]);
            IdRedesSociais = int.Parse(vetorCampos[3]);
            canal = vetorCampos[3];

        }
    }
}
